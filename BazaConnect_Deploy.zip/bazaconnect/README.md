# 🗺️ BazaConnect — East Africa AI Service Directory

> The AI-powered service directory for East Africa, accessible via WhatsApp.
> English · French · Swahili
> 🇧🇮 Burundi · 🇷🇼 Rwanda · 🇰🇪 Kenya · 🇺🇬 Uganda · 🇹🇿 Tanzania

---

## What is BazaConnect?

BazaConnect allows any citizen in East Africa to find essential service providers near them — doctors, notaries, city halls, pharmacies, banks — by writing a simple message. No app to download. No account to create. In their language.

---

## 🚀 Deploy in 10 Minutes — Step by Step

### Prerequisites
- A GitHub account (free) → https://github.com/signup
- A Vercel account (free) → https://vercel.com/signup
- An Anthropic API key → https://console.anthropic.com

---

### Step 1 — Upload to GitHub

**Option A: GitHub Desktop (easiest on mobile/Android)**
1. Install GitHub Desktop on your computer
2. Create a new repository named `bazaconnect`
3. Copy all these project files into the repository folder
4. Commit and Push

**Option B: GitHub Web (browser only)**
1. Go to github.com → New repository → name it `bazaconnect`
2. Click "uploading an existing file"
3. Drag and drop all files (keep the folder structure)
4. Click "Commit changes"

**Folder structure required:**
```
bazaconnect/
├── api/
│   └── chat.js
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx
│   └── main.jsx
├── .env.example
├── .gitignore
├── index.html
├── package.json
├── vercel.json
└── vite.config.js
```

---

### Step 2 — Deploy on Vercel

1. Go to **vercel.com** → Log in with GitHub
2. Click **"New Project"**
3. Select your `bazaconnect` repository
4. Vercel auto-detects it as a Vite project
5. Click **"Deploy"** — wait ~2 minutes

---

### Step 3 — Add your API Key (CRITICAL)

Without this step, the AI will not respond.

1. In Vercel → open your `bazaconnect` project
2. Go to **Settings** → **Environment Variables**
3. Click **"Add New"**
4. Fill in:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** your key starting with `sk-ant-...`
   - **Environment:** Production + Preview + Development (check all 3)
5. Click **Save**

---

### Step 4 — Redeploy

After adding the environment variable:
1. Go to **Deployments** tab in Vercel
2. Click the three dots `...` next to the latest deployment
3. Click **"Redeploy"**
4. Wait ~1 minute

---

### Step 5 — Test your live URL

Your app is now live at:
`https://bazaconnect-[random].vercel.app`

Test it:
- Write "I need a doctor in Nairobi" → should get a response in English
- Write "Je cherche un notaire à Bujumbura" → should respond in French
- Write "Ninahitaji dawa Dar es Salaam" → should respond in Swahili

---

## 🔧 Local Development

```bash
# Install dependencies
npm install

# Create your local environment file
cp .env.example .env.local
# Edit .env.local and add your ANTHROPIC_API_KEY

# Start development server
npm run dev
# → Open http://localhost:5173
```

---

## 📁 Project Structure

```
api/chat.js          → Serverless function: secure Anthropic API proxy
src/App.jsx          → Main React component: WhatsApp-style UI
src/main.jsx         → React entry point
index.html           → HTML root file
vercel.json          → Vercel routing configuration
vite.config.js       → Vite build configuration
package.json         → Dependencies
.env.example         → Environment variables template
```

---

## 🔐 Security Notes

- The `ANTHROPIC_API_KEY` is stored **only** in Vercel environment variables
- It is **never** exposed in the frontend code
- All AI calls go through the `/api/chat` serverless function (server-side only)
- The `.gitignore` ensures `.env.local` is never committed to GitHub

---

## 🌍 Supported Countries & Languages

| Country | Language | Mobile Money |
|---------|----------|-------------|
| 🇧🇮 Burundi | French + Kirundi | Lumicash, Ecocash |
| 🇷🇼 Rwanda | French + English + Kinyarwanda | MTN MoMo |
| 🇰🇪 Kenya | English + Swahili | M-Pesa |
| 🇺🇬 Uganda | English + Luganda | MTN MoMo, Airtel Money |
| 🇹🇿 Tanzania | Swahili + English | M-Pesa, Tigo Pesa |

---

## 📬 Contact

BazaConnect · bazaconnect.ai · contact@bazaconnect.ai
