import { useState, useRef, useEffect } from "react";

// ─── SUGGESTIONS ────────────────────────────────────────────────────
const SUGGESTIONS = [
  { lang: "EN", text: "I need a cardiologist in Nairobi, Westlands area" },
  { lang: "FR", text: "Je cherche un notaire à Bujumbura, quartier Rohero" },
  { lang: "SW", text: "Ninahitaji daktari wa watoto Dar es Salaam" },
  { lang: "EN", text: "Pharmacy open tonight in Kampala, Kololo" },
  { lang: "FR", text: "Documents pour acte de naissance à Kigali" },
  { lang: "SW", text: "Benki karibu na Mwanza, Tanzania" },
];

const FLAGS = ["🇧🇮", "🇷🇼", "🇰🇪", "🇺🇬", "🇹🇿"];

const getTime = () =>
  new Date().toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });

// ─── TYPING DOTS ─────────────────────────────────────────────────────
function TypingDots() {
  return (
    <div style={{ display: "flex", gap: 4, padding: "10px 14px", alignItems: "center" }}>
      {[0, 1, 2].map(i => (
        <div key={i} style={{
          width: 7, height: 7, borderRadius: "50%", background: "#F4A623",
          animation: `bazaBounce 1.1s ease-in-out ${i * 0.18}s infinite`,
        }} />
      ))}
    </div>
  );
}

// ─── TEXT RENDERER (supports *bold*) ─────────────────────────────────
function renderText(text) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*[^*]+\*)/g);
    return (
      <div key={i} style={{ minHeight: line === "" ? 6 : "auto" }}>
        {parts.map((p, j) =>
          p.startsWith("*") && p.endsWith("*")
            ? <strong key={j}>{p.slice(1, -1)}</strong>
            : p
        )}
      </div>
    );
  });
}

// ─── MAIN COMPONENT ──────────────────────────────────────────────────
export default function BazaConnect() {
  const [msgs, setMsgs] = useState([{
    from: "bot",
    text: "Hello / Bonjour / Habari 👋\n\nI'm *BazaConnect* — your AI service directory for East Africa.\n\nFind any provider near you: doctor, notary, city hall, pharmacy, bank, school...\n\nWrite in *English, French or Swahili* — I'll match your language.\n\nWhat do you need today?",
    time: getTime(),
  }]);
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [showSugg, setShowSugg] = useState(true);
  const [error, setError]     = useState(null);
  const bottomRef   = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, loading]);

  const send = async (text) => {
    if (!text.trim() || loading) return;
    const t = text.trim();
    setError(null);
    setMsgs(p => [...p, { from: "user", text: t, time: getTime() }]);
    setInput("");
    setLoading(true);
    setShowSugg(false);
    if (textareaRef.current) textareaRef.current.style.height = "auto";

    const newHist = [...history, { role: "user", content: t }];
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newHist }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP ${res.status}`);
      }

      const data  = await res.json();
      const reply = data.reply || "Sorry, something went wrong. Please try again.";
      setMsgs(p => [...p, { from: "bot", text: reply, time: getTime() }]);
      setHistory([...newHist, { role: "assistant", content: reply }]);
    } catch (err) {
      const errMsg = err.message?.includes("Failed to fetch")
        ? "⚠️ Network error. Check your connection and try again."
        : `⚠️ Error: ${err.message}`;
      setMsgs(p => [...p, { from: "bot", text: errMsg, time: getTime() }]);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); }
  };

  const reset = () => {
    setMsgs([{
      from: "bot",
      text: "Hello / Bonjour / Habari 👋\n\nI'm *BazaConnect* — your AI service directory for East Africa.\n\nWhat do you need today?",
      time: getTime(),
    }]);
    setHistory([]);
    setShowSugg(true);
    setError(null);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg,#0A0600 0%,#120A00 60%,#080400 100%)",
      display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      padding: 16,
      fontFamily: "'Segoe UI','Helvetica Neue',Arial,sans-serif",
    }}>
      <style>{`
        @keyframes bazaBounce{0%,60%,100%{transform:translateY(0);opacity:.35}30%{transform:translateY(-5px);opacity:1}}
        @keyframes bazaFade{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bazaPulse{0%,100%{opacity:1}50%{opacity:.45}}
        @keyframes bazaSpin{to{transform:rotate(360deg)}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:rgba(255,255,255,.1);border-radius:2px}
        textarea{resize:none;outline:none;border:none;background:none}
        button:active{opacity:.85}
      `}</style>

      {/* Country flags */}
      <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
        {FLAGS.map(f => (
          <span key={f} style={{ fontSize: 22 }}>{f}</span>
        ))}
      </div>

      {/* Phone container */}
      <div style={{
        width: "100%", maxWidth: 420,
        height: "86vh", maxHeight: 760,
        display: "flex", flexDirection: "column",
        background: "#111B21", borderRadius: 20, overflow: "hidden",
        boxShadow: "0 24px 80px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.06)",
      }}>

        {/* ── HEADER ── */}
        <div style={{
          background: "#1F2A1A", padding: "13px 18px",
          display: "flex", alignItems: "center", gap: 13,
          borderBottom: "1px solid rgba(255,255,255,.05)",
          flexShrink: 0,
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: "50%", flexShrink: 0,
            background: "linear-gradient(135deg,#F4A623,#E8820A)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 22, boxShadow: "0 2px 12px rgba(244,166,35,.45)",
          }}>🗺️</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, color: "#E9EDEF", fontSize: 15, letterSpacing: "-.2px" }}>
              BazaConnect
            </div>
            <div style={{ fontSize: 11, color: "#F4A623", display: "flex", alignItems: "center", gap: 5, marginTop: 2 }}>
              <span style={{
                width: 6, height: 6, borderRadius: "50%",
                background: "#F4A623", display: "inline-block",
                animation: "bazaPulse 2s ease-in-out infinite",
              }} />
              Online · East Africa AI Directory
            </div>
          </div>
          <div style={{
            background: "rgba(244,166,35,.12)", border: "1px solid rgba(244,166,35,.28)",
            borderRadius: 20, padding: "3px 10px",
            fontSize: 10, color: "#F4A623", fontWeight: 700, letterSpacing: "1px",
          }}>EN·FR·SW</div>
        </div>

        {/* ── MESSAGES ── */}
        <div style={{
          flex: 1, overflowY: "auto", padding: "14px 12px",
          background: "#0D1418", display: "flex", flexDirection: "column", gap: 3,
        }}>
          <div style={{ textAlign: "center", marginBottom: 10 }}>
            <span style={{
              background: "rgba(255,255,255,.07)", borderRadius: 20,
              padding: "3px 12px", fontSize: 11, color: "#6B7F8C",
            }}>Today</span>
          </div>

          {msgs.map((m, i) => (
            <div key={i} style={{
              display: "flex",
              justifyContent: m.from === "user" ? "flex-end" : "flex-start",
              alignItems: "flex-end", gap: 8, marginBottom: 3,
              animation: "bazaFade .22s ease",
            }}>
              {m.from === "bot" && (
                <div style={{
                  width: 26, height: 26, borderRadius: "50%", flexShrink: 0,
                  background: "linear-gradient(135deg,#F4A623,#E8820A)",
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13,
                }}>🗺️</div>
              )}
              <div style={{
                maxWidth: "74%",
                background: m.from === "user"
                  ? "linear-gradient(135deg,#5C3800,#704500)"
                  : "#202C33",
                borderRadius: m.from === "user" ? "14px 4px 14px 14px" : "4px 14px 14px 14px",
                padding: "9px 13px", fontSize: 13.5,
                color: "#E9EDEF", lineHeight: 1.55,
                boxShadow: m.from === "user"
                  ? "0 2px 8px rgba(80,40,0,.35)"
                  : "0 2px 8px rgba(0,0,0,.3)",
              }}>
                {renderText(m.text)}
                <div style={{
                  fontSize: 10.5, color: "rgba(255,255,255,.28)",
                  marginTop: 5, textAlign: "right",
                  display: "flex", justifyContent: "flex-end", alignItems: "center", gap: 3,
                }}>
                  {m.time}
                  {m.from === "user" && (
                    <span style={{ color: "#F4A623", fontSize: 12 }}>✓✓</span>
                  )}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div style={{ display: "flex", alignItems: "flex-end", gap: 8, animation: "bazaFade .2s ease" }}>
              <div style={{
                width: 26, height: 26, borderRadius: "50%",
                background: "linear-gradient(135deg,#F4A623,#E8820A)",
                display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13,
              }}>🗺️</div>
              <div style={{ background: "#202C33", borderRadius: "4px 14px 14px 14px" }}>
                <TypingDots />
              </div>
            </div>
          )}

          {/* Suggestions */}
          {showSugg && msgs.length === 1 && (
            <div style={{ marginTop: 14 }}>
              <div style={{ fontSize: 11.5, color: "#6B7F8C", textAlign: "center", marginBottom: 8 }}>
                💡 Try in any language
              </div>
              {SUGGESTIONS.map((s, i) => (
                <button key={i} onClick={() => send(s.text)} style={{
                  width: "100%", marginBottom: 6,
                  background: "rgba(244,166,35,.09)",
                  border: "1px solid rgba(244,166,35,.22)",
                  borderRadius: 18, padding: "8px 14px",
                  fontSize: 12.5, color: "#F4A623",
                  fontFamily: "inherit", textAlign: "left", lineHeight: 1.4, cursor: "pointer",
                }}>
                  <span style={{
                    fontSize: 10, background: "rgba(244,166,35,.2)",
                    borderRadius: 8, padding: "1px 6px", marginRight: 6,
                    fontWeight: 700,
                  }}>{s.lang}</span>
                  {s.text}
                </button>
              ))}
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* ── INPUT ── */}
        <div style={{
          background: "#1F2A1A", padding: "10px 12px 12px",
          borderTop: "1px solid rgba(255,255,255,.04)", flexShrink: 0,
        }}>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
            <div style={{
              flex: 1, background: "#2A3328", borderRadius: 22,
              padding: "9px 14px", display: "flex", alignItems: "flex-end",
            }}>
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKey}
                placeholder="EN · FR · Swahili — write your need..."
                rows={1}
                style={{
                  flex: 1, color: "#E9EDEF", fontSize: 13.5,
                  fontFamily: "inherit", lineHeight: 1.5,
                  maxHeight: 90, overflowY: "auto", width: "100%",
                }}
                onInput={e => {
                  e.target.style.height = "auto";
                  e.target.style.height = Math.min(e.target.scrollHeight, 90) + "px";
                }}
              />
            </div>
            <button
              onClick={() => send(input)}
              disabled={loading || !input.trim()}
              style={{
                width: 44, height: 44, borderRadius: "50%", border: "none", flexShrink: 0,
                background: loading || !input.trim()
                  ? "#2A3328"
                  : "linear-gradient(135deg,#F4A623,#E8820A)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 17, color: "#fff",
                boxShadow: input.trim() && !loading ? "0 3px 14px rgba(244,166,35,.5)" : "none",
                transition: "all .2s",
                cursor: loading || !input.trim() ? "default" : "pointer",
              }}
            >
              {loading
                ? <div style={{
                    width: 17, height: 17,
                    border: "2px solid rgba(255,255,255,.2)",
                    borderTop: "2px solid #F4A623",
                    borderRadius: "50%",
                    animation: "bazaSpin .7s linear infinite",
                  }} />
                : "➤"}
            </button>
          </div>

          {msgs.length > 2 && (
            <div style={{ textAlign: "center", marginTop: 9 }}>
              <button onClick={reset} style={{
                background: "none", border: "none", color: "#3D4F3A",
                fontSize: 11.5, fontFamily: "inherit",
                textDecoration: "underline", cursor: "pointer",
              }}>New conversation</button>
            </div>
          )}
        </div>

        {/* ── FOOTER ── */}
        <div style={{
          background: "#111B21", padding: "7px 14px",
          textAlign: "center", borderTop: "1px solid rgba(255,255,255,.03)",
          flexShrink: 0,
        }}>
          <span style={{ fontSize: 10.5, color: "#263028" }}>
            🗺️ BazaConnect · AI Directory · 🇧🇮🇷🇼🇰🇪🇺🇬🇹🇿 East Africa
          </span>
        </div>
      </div>
    </div>
  );
}
