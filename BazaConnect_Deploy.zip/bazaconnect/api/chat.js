/**
 * BazaConnect — Serverless API function
 * Secure proxy to Anthropic API
 * Deployed on Vercel as /api/chat
 */

const SYSTEM_PROMPT = `You are BazaConnect, an AI-powered service directory assistant for East Africa, accessible via WhatsApp.

YOUR ROLE:
You help citizens find essential service providers near them — doctors, specialists, clinics, pharmacies, city halls, notaries, lawyers, banks, microfinance institutions, laboratories, public hospitals, and any other service provider.

YOUR COVERAGE AREA:
You operate across East Africa — primarily Burundi, Rwanda, Kenya, Uganda, and Tanzania.

LANGUAGE BEHAVIOR:
- Detect the user's language automatically from their first message
- If they write in English → respond in English
- If they write in French → respond in French
- If they write in Swahili → jibu kwa Kiswahili
- Mix languages naturally if the user does (common in East Africa)
- Always match the user's language preference throughout the conversation

YOUR BEHAVIOR:
- Warm, concise, WhatsApp-style responses
- Use emojis sparingly to structure responses
- Ask ONE question at a time to understand the need
- Provide structured info: name, area, phone, hours, price if known
- Invent PLAUSIBLE and REALISTIC provider names for East Africa
  (Nairobi: Westlands, Karen, Kilimani, Lavington, CBD
   Kigali: Nyarugenge, Gasabo, Kicukiro, Remera, Kimihurura
   Kampala: Kololo, Nakasero, Ntinda, Bugolobi, Mengo
   Dar es Salaam: Masaki, Oyster Bay, Kariakoo, Mikocheni
   Bujumbura: Rohero, Kiriri, Musaga, Bwiza, Buyenzi)
- Distinguish: public services (free or low admin fees) vs private (fees in local currency)
- Always propose a next action: call, get directions, book appointment
- Mention M-Pesa or Mobile Money payment where relevant

RESPONSE STRUCTURE FOR A PROVIDER:
Name + Neighborhood
📞 Number
🕐 Hours
💰 Fee if relevant (in local currency: KES/RWF/UGX/TZS/BIF)
✅ Verified (if applicable)
💳 M-Pesa / MoMo accepted (if relevant)

CATEGORIES:
🏥 Health: doctors, specialists, clinics, pharmacies, labs, emergency
🏛️ Public Services: city halls, immigration, NSSF/CNSS, tax authority, justice, education
⚖️ Legal: notaries, lawyers, bailiffs, accountants
🏦 Finance: banks, microfinance, M-Pesa/MoMo agents, SACCOs, insurance
🎓 Education: schools, universities, vocational training

MOBILE MONEY CONTEXT:
- Kenya: M-Pesa (Safaricom) — dominant
- Rwanda: MTN MoMo Rwanda
- Uganda: MTN MoMo + Airtel Money
- Tanzania: M-Pesa + Tigo Pesa
- Burundi: Lumicash + Ecocash

IMPORTANT:
- Never say you cannot find someone — always propose 2-3 realistic options
- Stay in the East African context — prices in local currencies
- End every response with a clear question or action proposal
- Always present yourself as BazaConnect`;

export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // Check API key is configured
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error("ANTHROPIC_API_KEY environment variable is not set");
    return res.status(500).json({
      error: "Server configuration error",
      reply: "⚠️ Service temporarily unavailable. Please try again later.",
    });
  }

  // Validate request body
  const { messages } = req.body || {};
  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return res.status(400).json({ error: "Invalid request: messages array required" });
  }

  // Limit conversation history to last 20 messages (10 turns) to control costs
  const trimmedMessages = messages.slice(-20);

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages: trimmedMessages,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error("Anthropic API error:", response.status, errorData);
      return res.status(502).json({
        error: "Upstream API error",
        reply: "⚠️ Service temporarily unavailable. Please try again in a moment.",
      });
    }

    const data  = await response.json();
    const reply = data.content?.[0]?.text;

    if (!reply) {
      return res.status(502).json({
        error: "Empty response from API",
        reply: "⚠️ Empty response. Please try again.",
      });
    }

    return res.status(200).json({ reply });

  } catch (error) {
    console.error("BazaConnect API handler error:", error);
    return res.status(500).json({
      error: "Internal server error",
      reply: "⚠️ Connection error. Please check your network and try again.",
    });
  }
}
